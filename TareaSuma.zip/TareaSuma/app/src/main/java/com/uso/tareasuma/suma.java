package com.uso.tareasuma;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import static com.uso.tareasuma.MainActivity.TAG_MENSAJE;

public class suma extends AppCompatActivity {

    int numero1;
    int numero2;
    int resp;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.suma);
    }
    public void Respuesta(View v){
        Intent intentres   = new Intent(this, MainActivity.class);
        numero1= (int) (Math.random()*10);
        numero2 = (int)(Math.random()*10);
        resp= numero1+numero2;
        intentres.putExtra(TAG_MENSAJE, "La suma de "+numero1+" y "+ numero2+" es= "+resp);
        setResult(RESULT_OK, intentres);
        finish();
    }
}
