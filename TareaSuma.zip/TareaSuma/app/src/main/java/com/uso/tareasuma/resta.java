package com.uso.tareasuma;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import static com.uso.tareasuma.MainActivity.TAG_MENSAJE;

public class resta extends AppCompatActivity {

    int numero1;
    int numero2;
    int resp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resta);
    }

    public void Respuesta(View v){
        Intent intentr2   = new Intent(this, MainActivity.class);
        numero1= (int) (Math.random()*10);
        numero2 = (int)(Math.random()*10);
        resp= numero1-numero2;
        intentr2.putExtra(TAG_MENSAJE, "La Resta de "+numero1+" y "+ numero2+" es= "+resp);
        setResult(RESULT_OK, intentr2);
        finish();
    }

}
