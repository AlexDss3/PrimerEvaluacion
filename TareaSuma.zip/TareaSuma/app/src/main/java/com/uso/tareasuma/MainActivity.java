package com.uso.tareasuma;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    //declaración constantes estaticas
    public static final int ID_SUMA= 2;
    public static final int ID_RESTA= 3;
    public static final int ID_MULTI= 4;
    public static final int ID_DIVI= 5;
    public static final String TAG_MENSAJE = "MSJ";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void Suma(View v){
        Intent intent1   = new Intent(this, suma.class);
        startActivityForResult(intent1, ID_SUMA);
    }

    public void Resta(View v){
        Intent intent2   = new Intent(this, resta.class);
        startActivityForResult(intent2, ID_RESTA);
    }

    public void Multi(View v){
        Intent intent3   = new Intent(this, multiplicacion.class);
        startActivityForResult(intent3, ID_MULTI);
    }

    public void Divi(View v){
        Intent intent4   = new Intent(this, division.class);
        startActivityForResult(intent4, ID_DIVI);
    }

    public void onActivityResult(int RequestCode, int ResultCode, Intent datos){
        super.onActivityResult(RequestCode,ResultCode,datos);
        switch (RequestCode){
            case ID_SUMA:
                if(ResultCode==suma.RESULT_OK){
                    String mensaje= datos.getStringExtra(TAG_MENSAJE);
                    Toast resp=Toast.makeText(this, mensaje, Toast.LENGTH_LONG);
                    resp.show();
                }
                break;
            case ID_RESTA:
                if(ResultCode==resta.RESULT_OK){
                    String mensaje= datos.getStringExtra(TAG_MENSAJE);
                    Toast resp2=Toast.makeText(this, mensaje, Toast.LENGTH_LONG);
                    resp2.show();
                }
                break;
            case ID_MULTI:
                if(ResultCode==multiplicacion.RESULT_OK){
                    String mensaje= datos.getStringExtra(TAG_MENSAJE);
                    Toast resp3=Toast.makeText(this, mensaje, Toast.LENGTH_LONG);
                    resp3.show();
                }
                break;
            case ID_DIVI:
                if(ResultCode==division.RESULT_OK){
                    String mensaje= datos.getStringExtra(TAG_MENSAJE);
                    Toast resp4=Toast.makeText(this, mensaje, Toast.LENGTH_LONG);
                    resp4.show();
                }
                break;
        }
    }
}
